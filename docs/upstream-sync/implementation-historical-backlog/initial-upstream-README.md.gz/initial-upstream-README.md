# 上游合并指南

旧项专项复评（2026-11-25）：[历史未合内容报告](./UNMERGED-REVIEW-2026-11-25.md) / [134 PR、44类库存](./unmerged-review-2026-11-25/inventory.md) / [实际证据](./unmerged-review-2026-11-25/README.md)。以v1.1.28 / `b9d9524c6`重查1,843条文件状态A17/C1026/X654/N146。真实SQLite证明现有Token统计遗漏非gpt/已选平台，明确由旧第三档调整为[第一档F01，5项未实施任务](../../openspec/changes/port-upstream-historical-backlog-tier1/README.md)；native JSON/SSE证明Gemini200带内错误缺Ops标记，明确调整为[第二档S01，6项未实施任务](../../openspec/changes/port-upstream-historical-backlog-tier2/README.md)。其它第三档按Claude Code ToolSearch、搜索来源、可选5m策略、最大上下文/监控前缀等使用收益排序，支付与缺平台/PG边界保持。#7129既有序号合同核销，Fast/TPS/Grok诊断等后续完成项不重开。

- [x] 冻结整PR来源并先反后正，仅私有index检查；重测当前消费者、旧状态和初始工作区保护。
- [x] 当前四包98顶层/214含子例、前端4文件66测试通过；隔离探针6目标失败/5观察或控制通过，初始DNS夹具失败原文保留。
- [x] 实际SQLite/miniredis单P性能量测与当前生产依赖audit单列，不将合成可行性当实施或生产收益。
- [x] 两份完整未实施OpenSpec，5/6任务全未勾选、实施验收槽为空；严格校验与链接/范围复核。
- [ ] 按后续选定范围实施；其它按需能力保持原档位，发布/归档/业务实例操作另行处理。

本次教训：基于既有合同实证调整档位；可选能力失败不直接当缺陷；父metadata与子字段不能互称等价；SQLite少分配也可能变慢，fixed锚点语义不可省略；应关闭已经满足的旧标签。见[报告§9](./UNMERGED-REVIEW-2026-11-25.md#9-新的通用教训)。下方新增合并复核和历史快照保留原文。

最新复核（2026-11-25）：[新增合并复核](./RECHECK-2026-11-25.md) / [来源与范围证据](./recheck-2026-11-25/MANIFEST.md)。截至22:16上海时间，官方API与Git确认最新正式版仍为v0.2.25，main仍为`0f6671457`，自上轮观察后新增产品提交/合并均为0；fetch只更新CLA签名分支。当前本地v1.1.28 / `b9d9524c6`已包含F01/S01/S02三簇17任务，15份最终实现源码/测试/模块哈希匹配。未新增提案或实施；头身份变量、名称备注同步及历史按需项保持原档位。下方发布前快照保留原文。

- [x] 刷新上游refs，交叉核对最新Release、main与完整新合并搜索，区分CLA更新和产品合并。
- [x] 核实v1.1.28已落地状态、15份实现哈希、15份活动OpenSpec/456完成任务及历史遗留。
- [x] 保存独立复核证据与文档入口；保护产品、冻结历史及初始Fast诊断，无新增测试通过声明。

本次复核教训：比较上次观察main而非只比较tag；CLA签署不等于PR合并；历史intake的未实施措辞需由实际实现/发布状态解释；空增量不重复制造提案或验收。见[复核§9](./RECHECK-2026-11-25.md#9-本轮通用教训)。

2026-11-24 用户后续已授权将v0.2.25两档实现提交并推送origin/main；本次提交包含实现、两档OpenSpec、评估来源和实际验收证据。原先未跟踪的Fast诊断留在工作区。产品/模块与通过验收的最终哈希一致；VERSION1.1.27及现有tag保持，不发布、不归档、不操作业务实例。下方实施与intake段落保留完成时的快照措辞。

2026-11-24 两档已实现并验收：[第一档F01，6/6任务](../../openspec/changes/port-upstream-0.2.25-tier1/verification.md)、[第二档S01/S02，11/11任务](../../openspec/changes/port-upstream-0.2.25-tier2/verification.md)。[实施证据](./implementation-0.2.25/README.md)记录账号凭据/主机脱敏、有限结构化错误/原body规则/compact单次有序终态及Gorilla精确安全维护。55包unit、10,793顶层/22,386含子例通过，16既有跳过；三包错误/SQLite race332/669、五包WS race693/1,351、embed、lint0与实际HTTP/compact/管理员WS/CONNECT/SQLite/miniredis/计费配额控制通过。原库两项代理EOF由Go1.27.4非Hijack CONNECT夹具关闭定因；失败保留，临时真隧道夹具双版本通过。MVS仅Gorilla变化；版本/schema/其它依赖/前端/生成代码/资源默认与旧13活动change、439任务、冻结历史和初始Fast诊断保持。改动留在工作区，未提交/推送/发布/归档或操作业务实例。下方同日intake保留实施前措辞。

最新评估（2026-11-24）：[PORTING-0.2.25.md](./PORTING-0.2.25.md)，v0.2.24→v0.2.25；正式版发布于2026-11-24 11:21:08上海时间。当前基线v1.1.27 / `39ca66d51` / Go1.27.4 / SQLite230 / auth21，已含v0.2.24两档。12非merge、3整PR+1 VERSION提交，98文件状态A0/C56/X32/N10。建议[第一档1簇/6任务](../../openspec/changes/port-upstream-0.2.25-tier1/README.md)、[第二档2簇/11任务](../../openspec/changes/port-upstream-0.2.25-tier2/README.md)，**均未实施，验收槽为空**。优先已有透传消息泄露、标准错误字段/规则与compact；Gorilla安全维护独立评估。头身份变量、上游名称同步留第三档，支付排除。[来源与完整局限](./evidence-0.2.25/MANIFEST.md)。下方保留历史原文。

- [x] 官方API/tag/main/fork冻结，完整候选覆盖、先反后正，保护产品/历史与初始Fast诊断。
- [x] 全候选四档定界，复核实际消费者、最小前置及旧13份活动change/439已完成任务。
- [x] 当前backend274顶层/548含子例、前端67测试通过；隔离探针5目标顶层失败/4控制通过。
- [x] 来源helper独立10含子例通过；临时MVS只改Gorilla，应用WS376/700与真实CONNECT通过，库自身失败保留。
- [x] 两档完整未实施OpenSpec与来源/链接/范围核验，无VERSION/schema/依赖/生成代码变动。
- [ ] 后续按选定范围实施验收；依赖历史代理EOF仍需定因，不把可行性写成升级完成。

本轮教训：新增函数安全修复不等于本地已有漏洞；监控事件与最终writer可能只执行部分规则；标准code保留需与脱敏、compact容量码和共享序号组合；单模块升级也看完整行为diff；真实隧道通过不能擦掉依赖历史失败。见[§9](./PORTING-0.2.25.md#9-本轮通用教训)。

2026-11-21 两档已实现并验收：[第一档37/37](../../openspec/changes/port-upstream-0.2.24-tier1/verification.md)、[第二档52/52](../../openspec/changes/port-upstream-0.2.24-tier2/verification.md)，25簇共89任务。[联合证据](./implementation-0.2.24/README.md)记录全入口/WS防重复、协议/账号/快照/配额/目录/统计与窄热点适配。55包unit、9包race、lint0/embed/Wire、实际HTTP/WS/SQLite/miniredis/成本与固定quota/dedup、前端2254/2原skip和桌面移动通过；1C1G独立并发夹具与单P函数成本分开限定。VERSION1.1.26/Go1.27.4/SQLite230/auth21、依赖/Ent与资源默认保持。实现随本次本地提交保存，等待归档；无push/release/业务实例操作。下方intake评估原文保留当时时点的未实施措辞。

最新评估（2026-11-21）：[PORTING-0.2.24.md](./PORTING-0.2.24.md)，v0.2.23→v0.2.24；最新正式版发布于2026-11-20 17:19:50上海时间。基线`d2488b110` / VERSION1.1.26 / Go1.27.4 / SQLite230 / auth21，包含两档旧移植、GPT-6.2及过滤/effort日志。65非merge、39PR+1直接提交+1安全合并簇，217文件态A0/C135/X62/N20。建议[第一档10簇](../../openspec/changes/port-upstream-0.2.24-tier1/README.md)、[第二档15簇](../../openspec/changes/port-upstream-0.2.24-tier2/README.md)，选30PR+安全簇，**均未实施，37/52任务全未勾选**。[来源与核验](./evidence-0.2.24/MANIFEST.md)。

- [x] 官方API/tag/main/fork冻结；整PR及最终安全merge完整覆盖，全部文件先reverse后forward。
- [x] 四档逐项、真实消费者/最小前置及历史遗留复核，优先重复字段安全、Claude/Codex/Grok和SQLite。
- [x] 九包相关基线869顶层通过/1原跳过；前端69通过。隔离Go探针17目标失败/10控制或观察通过，前端2失败/1控制通过，初始夹具错误另存。
- [x] 来源scanner隔离85例通过及单P成本；scheduler合成投影PoC，限定测量口径。
- [x] 两份未实施OpenSpec、严格校验、链接/空验收槽与产品/历史保护哈希核验。
- [ ] 后续按选定范围实施、实际HTTP/WS/SQLite/race/浏览器与资源验收；按需能力、发布及部署另行处理。

本轮教训：最终无PR合并也可能是关键安全来源；局部JSON防重不等于全入口；不可逆token轮换应与可选enrichment截止分开；已选能力的后续缺口不重复schema；累计耗时速率与窗口TPS算术mean分开；缺来源helper名字不等于无本地消费者。见[§9](./PORTING-0.2.24.md#9-本轮通用教训)。下方历史记录保留原时点含义。

2026-11-19 两项按需功能已实施，共 12/12 项：[透传账号按模型筛选（#8748）](../../openspec/changes/port-upstream-passthrough-model-filter/verification.md)、[用量日志的请求与实际推理强度（#6188）](../../openspec/changes/port-upstream-usage-reasoning-effort/verification.md)。SQLite 迁移 230。[本地适配位置](./PORTING-passthrough-filter-and-usage-effort.md) · [实施验收](./implementation-passthrough-filter-and-usage-effort/README.md)。

用户选定GPT-6.2 Sol/Astra已完成（2026-11-19）：[范围](./PORTING-gpt62.md)、[12/12验收](../../openspec/changes/port-upstream-0.2.23-gpt62/verification.md)、[实施证据](./implementation-gpt62/README.md)。两模型及Codex/协议/白名单/OpenCode、冻结官方价卡与双层fallback、严格272k计价、Fast2倍、Ultra Fast在太平洋2027-03-01 00:00前3倍/之后6倍，按请求/WS每轮时刻结算。官网在线核验502/403未完成，依据PR8906保存价卡。全量54测试包/四包race及后续清理复验、lint0/embed、实际本地HTTP/WS/SQLite48场景、前端2213/2原跳过与typecheck/lint/build通过。实现随本次提交保存，等待归档，版本/schema/依赖/生成代码及历史来源保留；套餐放行和新强制/渠道字段仍独立。共享工作区发布流程及测试脚本的并行修改单独记录。

v0.2.23第二档已完成（2026-11-18）：S01–S23、76/76任务，[验收](../../openspec/changes/port-upstream-0.2.23-tier2/verification.md) / [实施证据](./implementation-0.2.23-tier2/README.md)。Go1.27.4对齐；VERSION1.1.25、SQLite229、auth21、库/前端依赖、Ent/Wire及64MiB/40MiB/120s保留。54包unit/embed/lint0/六包race、实际HTTP/WS/SQLite/miniredis/Fast/结算去重通过；前端2212/2原跳过、critical179/2和桌面/移动操作通过。实际TCP202→1flush，1C1G独立夹具峰值69771264B，非生产性能承诺。起点为7a0b78fe5加第一档工作树；第一档在期间独立提交d8d126da9，55文件匹配。本批实现随本次本地提交保存，等待归档；无推送/发布/归档/业务实例操作。以下评估与历史时点原文保留。

最新评估（2026-11-18）：[PORTING-0.2.23.md](./PORTING-0.2.23.md)，覆盖v0.2.22/v0.2.23，基线v1.1.25+用量排行修复`7a0b78fe5` / Go1.27.3 / SQLite229 / auth21。128非merge、78PR+4直接提交，524文件态A0/C269/X199/N56。建议[第一档21簇](../../openspec/changes/port-upstream-0.2.23-tier1/README.md)、[第二档23簇](../../openspec/changes/port-upstream-0.2.23-tier2/README.md)，选55PR中的既有消费者维护，**两批未实施，70/76任务全未勾选**。[来源/失败/测量索引](./evidence-0.2.23/MANIFEST.md)。六份旧活动change共180完成checkbox、零未完成，等待归档；下方历史时点原文保留。

- [x] 冻结fork/release/tag/main，整PR覆盖与全部文件先反后正，保护历史和产品哈希。
- [x] 全候选分档，复查真实消费者/最小前置及旧按需项，优先Claude/Codex/Grok和SQLite数据完整性。
- [x] backend定向/前端89基线通过；6包overlay26目标失败/20对照通过，含实际SQLite/Ent/embed；临时前端9失败/11通过。
- [x] Go1.27.4只读embed/3包可行性与Ollama单P函数PoC；来源SSE转义字段漏判已保留，不作为可直接移植证据。
- [x] 两份OpenSpec评估方案、全部任务未勾选和实施验收空槽；严格校验/链接/范围见证据。
- [ ] 按后续选定范围实施；新能力独立按需，支付排除，发布/部署另行处理。

本轮教训：同PR最终提交可能推翻release摘要（Gemini ForceCacheBilling）；ALREADY=0也可能已手工实现RPM/刷新/override语义；cache presence/TTL/差额需联合检验；SSE字节predicate必须处理JSON转义；首内容hold需有界；SQLite失败原子性和临时测试runner须实际检查；新Go编译不等于新CI/codegen验收。见[§9](./PORTING-0.2.23.md#9-本轮通用教训)。

v0.2.21第二档已完成（2026-11-12）：S01–S12，42/42任务；[验收](../../openspec/changes/port-upstream-0.2.21-tier2/verification.md) / [实施证据](./implementation-0.2.21-tier2/README.md)。实际起点`4f4c80c3c`加已有第一档代码，第一档在期间由独立流程提交`63c764704`；本批实现随本次提交保存，等待归档。覆盖WS会话/搜索/TTFT、模型冷却、兼容错误/effort、token原子轮换、Key独立用量/SQLite覆盖索引、账号刷新、Desktop页面上下文、审计worker唤醒和Claude2.1.321。后端全量unit/embed build/lint0、五包race、真实HTTP/SQLite/miniredis结算去重/Fast/固定配额通过；前端2197/2既有跳过、critical179/2、typecheck/lint/build及桌面/390px移动验收通过。新增SQLite229；1GiB/1CPU临时夹具峰值66850816字节，索引查询/写入/大小成本已记录，不能外推生产。S11另修真实SQLite混合时间格式claim比较。VERSION1.1.24/Go1.27.3/auth snapshot21、依赖/生成代码与64MiB/40MiB/120s保留。无支付、新能力、推送/发布或业务部署；下方来源/评估/历史状态不回写。

v0.2.21第一档已完成（2026-11-11）：F01–F11，39/39任务；[验收](../../openspec/changes/port-upstream-0.2.21-tier1/verification.md) / [实施证据](./implementation-0.2.21-tier1/README.md)。基于`4f4c80c3c`，独立tier1快照54包unit、embed build、lint0、五包race126顶层测试及实际HTTP/SQLite/miniredis通过。覆盖Codex协议/会话/错误状态、并发槽释放、定价hash与缓存读价、Gemini思考与工具媒体、UTF-8边界。共享工作区出现并行tier2改动，额外修改不归入本批验收；完整tier1 patch仍在共享工作区。保持VERSION1.1.24/Go1.27.3/SQLite228/auth snapshot21、依赖/前端/生成代码及64MiB/40MiB/120s默认值。实现随本次提交保存，未发布/推送/业务部署；下方评估状态保留原始时点含义。

最新评估（2026-11-11）：[PORTING-0.2.21.md](./PORTING-0.2.21.md)，v0.2.20→v0.2.21，基线已发布v1.1.24 / `4f4c80c3c` / Go1.27.3 / SQLite228 / auth snapshot21。44非merge、33PR+1直接提交，214候选文件态A0/C121/X80/N13。建议[第一档11簇](../../openspec/changes/port-upstream-0.2.21-tier1/README.md)、[第二档12簇](../../openspec/changes/port-upstream-0.2.21-tier2/README.md)，**两批提案未实施**。完整来源、探针与核验见[证据索引](./evidence-0.2.21/MANIFEST.md)。旧v0.2.20两档已实现并包含于v1.1.24，下方旧评估措辞保持历史原意。

- [x] 冻结release/tag/main/fork，完整PR覆盖与全部文件先反后正，保护产品及历史哈希。
- [x] 全候选分档并重述旧遗留；核实最小前置，优先Claude Code、Codex和共享网关正确性。
- [x] 后端8包定向基线、前端59测试通过；四包overlay编译并复现16个顶层行为缺口，负对照通过。
- [x] 实际modernc SQLite完整基线迁移（最大编号228）、20000合成记录验证覆盖索引可行性；不作为生产收益或实施验收。
- [x] 建立两份未实施OpenSpec；所有实施任务未勾选，verification证据槽为空。
- [ ] 按后续用户选定范围实施与验收；新能力按需，支付排除。

本轮教训：发布说明里的修复可能只对应新增字段（12h TTL/Fast）；自适应预算的最低1GiB不能保护1GiB实例；terminal/item.done/delta应分别验字段；原子token轮换需可控并发复现；槽位补偿要保留本地会话释放；小helper与缺完整消费者分开；SQLite覆盖查询计划不等于生产收益。见[§9](./PORTING-0.2.21.md#9-本轮通用教训)。

v0.2.20第二档已完成（2026-11-10）：S01–S11，38/38任务；[实际验收](../../openspec/changes/port-upstream-0.2.20-tier2/verification.md) / [实施证据](./implementation-0.2.20-tier2/README.md)。基于第一档`29681fdf5`，后端全量unit/embed build/lint0、定向race及真实HTTP/SQLite/miniredis通过；frontend2186/2既有跳过、critical179/2、typecheck/lint/build和实际浏览器导出/429/耗尽/离页取消/移动端通过。64MiB请求体预算经1GiB/1CPU隔离压力验证；默认SSE行40MiB，读写停滞120秒。VERSION1.1.23/Go1.27.3/SQLite228、依赖/Ent不变；auth snapshot21，Wire重新生成共享缓存清理。实现于2026-11-11随本次提交保存，等待归档，无发布或业务部署；历史评估与来源保持冻结。

本轮实施经验：来源的后台图片入口判断要在实际起点复查；缓存过期与手动清扫不能重复创建timer；最后终态必须优先于先前completed；资源层压力不应宣传成完整实例总堆保证；导出重试必须保留取消和换号边界。

v0.2.20第一档已完成（2026-11-10）：F01–F13，44/44任务；[验收](../../openspec/changes/port-upstream-0.2.20-tier1/verification.md) / [实施证据](./implementation-0.2.20-tier1/README.md)。基于Fast已完成`326513cdc`，54包unit、embed build、lint0、六包race、实际HTTP/SQLite结算去重与周用量通过。VERSION1.1.23/Go1.27.3/SQLite228、依赖/前端/生成代码不变；实现随本次提交保存、等待归档，第二档仍未实施，无发布或业务部署。下方评估段落保留实施前历史状态。

最新评估（2026-11-10）：[PORTING-0.2.20.md](./PORTING-0.2.20.md)，v0.2.19→v0.2.20，基线Fast已完成提交`326513cdc` / VERSION1.1.23 / Go1.27.3 / SQLite228。72非merge、35PR+7直接提交，562候选文件态A3/C330/X157/N72。建议[第一档13簇](../../openspec/changes/port-upstream-0.2.20-tier1/README.md)、[第二档11簇](../../openspec/changes/port-upstream-0.2.20-tier2/README.md)，**两提案未实施**。优先Claude/Codex/Grok及Bedrock边界、资源治理；10包定向基线、77前端测试通过，14个顶层缺陷探针按新行为预期失败，负对照通过。[完整证据](./evidence-0.2.20/MANIFEST.md)。产品与历史证据未修改，无发布/推送/部署；main发布后#8610/#8606另列观察。

本轮待办：两份OpenSpec实施任务全部未勾选；第三档按实际用途选定，第四档及支付不做。Fast/Terra/Grok诊断/历史兼容/TPS分布按当前完成记录核销，旧段落保留历史时点。

v0.2.20通用教训（[§9](./PORTING-0.2.20.md#9-本轮新增通用教训)）：

- annotated tag对象与源码commit分列；并发提交以产品哈希确认基线一致。
- Release说明的`security.*`与tag实际`gateway.*`配置有差异，核对真实消费者后再写部署说明。
- 资源预算必须和后续所有权/failover修复组合；1GiB实例不能照搬1GiB预算与500MiB行上限。
- 来源测试缺接口先适配本地复现，不能靠引入新能力“修测试”；Grok562行基座也可拆成窄委派转换。
- 当前依赖审计与历史风险分开，本轮生产12moderate/2low不等于全量无风险。

用户选定 Fast/Free Fast/Ultrafast 已完整整合（2026-11-10）：[范围](./PORTING-fast-tiers.md)、[OpenSpec](../../openspec/changes/port-upstream-fast-tiers/README.md)、[使用与验收](./implementation-fast-tiers/README.md)。补齐各入口转发/目录/计价/分组与渠道配置，SQLite228、鉴权快照20；VERSION1.1.23、Go1.27.3、依赖不变。全量unit、race、构建、lint、真实SQLite与浏览器验证通过，变更保留工作区。历史文档保持原状态快照，其它第三档能力独立；没有发布或业务部署。

用户选定窗口输出TPS已实现（2026-11-04）：[补充范围与patch sites](./PORTING-output-tps-distribution.md)、[OpenSpec](../../openspec/changes/port-upstream-output-tps-distribution/README.md)、[实际验收证据](./implementation-output-tps-distribution/README.md)。历史#7911日志TPS已完成，本次补齐运维整窗口P5/P10/P50/均值/样本数，采用SQLite连续插值，raw/auto/preagg口径一致；自身2秒超时保留概览，父取消/截止和其它数据库错误传播。54包backend unit、embed build、lint0、三包定向race及SQLite/adminHTTP通过；frontend2174/2既有跳过、typecheck/lint/build/critical及真实浏览器桌面/全屏/移动/筛选/刷新通过。保留VERSION1.1.22、Go1.27.3、SQLite227和依赖/生成代码，实现已提交`f333aa5f3`，未部署业务实例；本次第三档已获用户选择，其它按需能力独立。新增通用经验：窗口分位数必须由逐请求样本计算，不能合并小时分位数；SQLite取消可能丢弃连接，执行中断测试不能依赖连接私有内存库。

OpenSpec 归档（2026-11-01）：9 个已完成活动变更、305 项任务已归档；当前共 28 个归档、1,073 项已关闭任务，活动变更为 0。74 个主规格汇总 356 个非支付需求，本次新增 105 个需求并更新 1 个既有需求。主规格记录 WS 默认 1.0、SQLite 227 配额清理和已批准的净化器维护边界；来源、方案、设计、delta 规格、任务、验收及历史证据原文保留，九份原 README 另存归档前快照。见[归档清单](../../openspec/changes/archive/README.md)、[主规格](../../openspec/specs/)与[归档核对](../../openspec/changes/archive/verification-followup-2026-11-01.json)。下列评估与实施条目保留原时点口径，当前完成状态以归档清单为准。

用户选定兼容性与Grok诊断已完成（2026-10-31）：[补充范围](./PORTING-0.2.19-personal-compatibility.md) / [实际证据](./implementation-historical-client-compatibility/README.md)。本地main实现`becd2d2a31192e13bdc431bc43fbe44436e2c319`，C01–C04 17/17、Grok诊断D01–D03 12/12。后端54包unit/embed构建/lint0、四包456和WS相邻74 race、SQLite468保护通过；前端2169/2 skipped、typecheck/lint/build/critical与真实浏览器通过。保留模型参考价格提交、VERSION1.1.21、Go1.27.3、迁移227、依赖及生成代码，原评估/来源/历史哈希不回写。两change活动待归档，其它按需能力独立，未发布或部署业务实例。

历史未合项复查（2026-10-31）：[当前建议与证据](./UNMERGED-REVIEW-2026-10-31.md)，基于已发布v1.1.21 / `e44324231` / Go1.27.3 / SQLite227，既有7份活动change的276/276任务均已完成。重新复现工具参数、custom别名、孤儿defer和Responses序号四项兼容性尾项，建议[独立第二档方案](../../openspec/changes/archive/2026-11-01-port-upstream-historical-client-compatibility/README.md)，**方案未实施**；后续优先按需选择Grok目录诊断，其它能力继续按用途。本次复查未扩展到新的上游release，历史来源/验收记录保留原时点值。

最新评估（2026-10-28）：[PORTING-0.2.19.md](./PORTING-0.2.19.md)，v0.2.18→v0.2.19，fork `49939fb2c` / VERSION1.1.20 / Go1.27.3 / SQLite227。50非merge、20PR+3直接提交，276文件先反后正A0/C203/X61/N12。建议第一档7簇、第二档6簇；用户选定GPT-6.1 Terra，仍为第三档、单独提案。评估时三份均未实施，评估证据保持当时的产品/版本/迁移/依赖值。[来源与基线证据](./evidence-0.2.19/MANIFEST.md)。

用户选定 Terra 实施（2026-10-30）已完成：[14/14 OpenSpec验收](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.19-terra/verification.md) / [实际证据与哈希](./implementation-0.2.19-terra/README.md)，本地 main 实现提交 `a541d0b611f4c2da5cab9811c3c4e02ae8344136`，起点 `b9e51e273`。六档/default medium、none/max与工具协议、metadata/raw目录/ETag、冻结价格/两层fallback/显式0/272k边界、HTTP/SSE/WS与SQLite结算、白名单/映射/OpenCode配置均验收。54包unit、embed构建、5包race、SQLite227/quota/固定窗口/dedup、lint0 issues通过；前端2106/2 skipped、typecheck/lint/build/critical与实际浏览器保存/重开/复制通过。VERSION1.1.20/Go1.27.3/迁移227、依赖与Ent/Wire保持，源/规格/历史证据冻结；仍属用户选定第三档，待归档，其他按需能力/支付/发布/push/部署/业务实例操作不在范围内。

第二档实施（2026-10-29）已完成：[OpenSpec 验收](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.19-tier2/verification.md) / [实际证据与哈希](./implementation-0.2.19-tier2/README.md)，23/23 任务，本地 main `cccf931efe201671f8cd27284b04e74114f4f894`。Grok 原文模型审计与目录/SQLite CAS、上传完整性、搜索维度、既有 Gemini 目录/默认测试和 x/net 最小维护完成；54 包 unit/build、7 包相关/network race、SQLite227/quota/fixed-window/dedup、lint0 issues，前端2105/2 skipped、typecheck/lint/build/critical及真实浏览器通过。用户确认 S01 保持迁移227，冲突位到 usage 边界并验证SQLite回退；原规格快照保留。VERSION/Go/schema、前端依赖与生成代码保持，剩余 audit 单列；冻结评估保持原文，Terra独立未实施，无支付/发布/push/部署/业务实例操作。

第一档实施（2026-10-29）已完成：[OpenSpec验收](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.19-tier1/verification.md) / [实际证据与哈希](./implementation-0.2.19-tier1/README.md)，26/26任务，提交本地main为`683354b2cdd2461dc581fa14158be09ef51de29b`。Claude UTF-16、Codex cache flight、共享cache-hit用量、Gemini file图片、Antigravity畸形工具、分页和管理员400保护七项完成；54包unit/build、8包race、SQLite迁移/quota/dedup、lint0 issues及OpenSpec通过。最终unit隔离测试子进程代理，SDK本地端点代理误匹配的控制证据已记录，相关验证码代码未改。VERSION1.1.20/Go1.27.3/迁移227、依赖/前端/生成代码不变；评估来源/第二档/Terra提案保持冻结，后两者仍未实施；未归档/发布/push/部署/操作业务实例数据。

- [x] 冻结tag/HEAD、整PR覆盖和全部四态，复查3732产品哈希与原始证据。
- [x] 23候选全部分档，优先Claude/Codex/Grok，真实缺陷、最小前置和旧完成/按需状态重述。
- [x] 建立[第一档](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.19-tier1/README.md)、[第二档](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.19-tier2/README.md)、[用户选定Terra](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.19-terra/README.md)三份OpenSpec，实施任务全部未勾选、verification实施证据槽全部空白。
- [x] backend实际测试目录/10包定向及Terra邻近回归、61前端测试、SQLite与Grok缺陷probe、x/net隔离PoC/MVS可行性检查。
- [x] 三提案严格校验、链接/来源/空实施槽与最终范围哈希核对。
- [x] 实施第一档7簇并完成[实际验收](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.19-tier1/verification.md)，26/26任务。
- [x] 实施第二档6簇并完成[23/23 实际验收](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.19-tier2/verification.md)。
- [x] 实施已选定第三档Terra并完成[14/14实际验收](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.19-terra/verification.md)。

v0.2.19通用教训（[§9](./PORTING-0.2.19.md#9-本轮新增通用教训)）：

- 缓存函数名不同不等于无此缺陷，沿实际消费者复现flight窗口。
- 新CLEAN文件仍可能是PG CAS；单键观测必须与普通旧表单、外部事务和缓存发布一并验收。
- SQLite JSON null 根也要验单键更新；空目录/非法形态、最后成功/最后尝试必须分开。实际页面可能使用另一份同名组件；异步背景请求和实时毫秒字段不能写成脆弱夹具断言。
- 11行事务helper可复用已有边界，不引入未选定9000行授权能力；34行目录收集/匹配也不需要整344行模型端点系统。
- 新模型要贯通effort/工具/metadata/价格/usage；来源占位created不是发布时间，用户选择第三档时保留原档位。
- 新模型的实际 none 能力需沿映射后的 HTTP/WS 出口验收；账号 URL 的占位过滤不能静默吃掉 Terra 的请求。SQLite race 夹具完整迁移一次后复制独立数据库；重放结算需保留同一请求上下文身份。
- 安全依赖先量最小MVS；PoC、实际可达与利用性分开；当前audit与历史证据、评估PASS与修复验收分开。

用户选定个人维护（2026-10-28）已完成：[补充与patch sites](./PORTING-0.2.18-personal-maintenance.md) / [OpenSpec验收](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.18-personal-maintenance/verification.md)。SQLite清理/到期暂停/定时测试恢复，操作日志“全部清理”SQL与Enter防重复提交修复；#8249延迟探测与#8250零分配签名实施。后端54包unit/build、四包race、SQLite迁移/quota/dedup、lint0 issues通过；前端2099通过/2既有跳过，typecheck/lint/build/critical通过。实现已提交至本地main为`b554bea554202e3008b99e3faa7a29420467f318`；VERSION1.1.20/Go1.27.3/迁移227/依赖/生成代码及历史冻结证据不变，未发布/部署/清理业务实例。[证据和哈希](./implementation-0.2.18-personal-maintenance/README.md)。

- [x] 三个SQLite后台逐项审查、旧时间兼容、取消/停止/重叠与真实数据库验收。
- [x] 操作日志SQLite清理、现场TOTP/权限/留痕和四项按钮事件回归。
- [x] 两项轻量调度优化、消费者接入、前后benchmark、race和组合门禁。

本次结论：时间扫描与比较分别验证；结果持久化失败不能恢复/推进；Enter需要方法防重入；夹具缺函数、旧参数mock和计数race先归因。其它按需项独立，支付排除。

本 fork 基于 [Wei-Shaw/sub2api](https://github.com/Wei-Shaw/sub2api)，但 **git 历史已重写**（最早一条提交就是 SQLite 改造，和上游没有共同祖先）。因此 **不要** `git merge upstream/main`，按功能 cherry-pick / 手工移植。

OpenSpec 整理（2026-10-24，含用户确认后的补充归档）：19 个已完成变更已归档，42 个主规格汇总 251 个非支付需求；归档后保留的历史活动变更为 0.2.0 第二档与 0.2.5 第二档。用户确认完成的四批通过各自 completion-record 关闭旧任务，并保留任务与验收原始快照。见[归档清单与保留原因](../../openspec/changes/archive/README.md)。冻结来源和原始证据保持原文。

用户选定个人功能（规格2026-10-24，开发验收2026-10-26）：[补充评估与patch sites](./PORTING-0.2.18-personal-features.md) / [OpenSpec](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.18-personal-features/README.md)。日志输出TPS、平台/状态筛选记忆、运维详情账号名、模型级冷却规则、OpenAI API Key搜索模拟、最小输出Token配置六项已实现，后续选定的完整运维页入口也已恢复。详见[验收及完成工作树哈希](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.18-personal-features/verification.md)。实现已提交为`0e38d06d8`；原第三档历史和冻结来源不改写，其他按需项与支付边界不扩展。用户后续要求发布v1.1.20，VERSION另升1.1.20，见[发布说明](../releases/v1.1.20.md)与[发布前检查](../releases/evidence-v1.1.20/readiness.md)；change尚未归档，未部署业务实例。

- [x] 实施F01–F03的日志/筛选/运维展示及异常、列偏好、缓存生命周期验收；恢复完整/admin/ops、侧栏和菜单项并保留权限/开关与其他页面限制。
- [x] 实施F04–F06的作用范围、搜索配置与网关转换，真实SQLite/miniredis/simple mode、Messages handler、用量归属及错误/取消/资源释放通过。
- [x] 完成组合门禁并填写独立verification：后端54个测试包、定向race/SQLite，前端2089通过/2项既有跳过、typecheck/lint/build；无迁移/依赖/VERSION变化。

补充评估教训：同名兼容helper不等于相同接入能力；配置继承需核对实际UI保存者；用精确delta解除旧批次范围限制，见[补充§9](./PORTING-0.2.18-personal-features.md#9-本次通用教训)。

个人功能实施教训：异步用量任务入队前快照请求上下文；SSE取消需要检查每个Write/Flush边界；手动刷新不能复用旧快照；明确凭据失败的判断需覆盖所有既有可达平台。见[整合审查](./implementation-0.2.18-personal-features/review.md)与[补充实施记录](./PORTING-0.2.18-personal-features.md#10-实施完成补记2026-10-26)。

最新实施教训：流服务返回部分结果后，还必须验证真实handler的队列溢出策略、请求字段快照与SQLite账本；目标Go补丁升级也可能改变导出格式，必要依赖前置须测最小版本并重扫安全记录。

v0.2.18评估通用教训（[0.2.18 §9](./PORTING-0.2.18.md#9-新增通用教训)）：共享map先追生产所有权；混合PR按已有消费者拆分；fork可能已移动helper；小前置随消费者摘取但缺消费者仍不适用；断流验收同时看终态、用量和资源释放；当前audit与package级命中不能冒充修复或利用证明。

v0.2.18历史检查清单（实施补记2026-10-24）：

- [x] 冻结v0.2.16→v0.2.18与fork `873962ce7`：56非merge、35PR、8直接提交；312文件全体先反向后正向，A4/C170/X117/N21。
- [x] 43候选全量分档、关键调用/缺前置量测、旧遗留重述和integration build tag核查。
- [x] 第一档6簇/第二档10簇OpenSpec提案，覆盖18PR及1直接测试提交；用户明确新能力暂缓，支付排除。
- [x] Go测试目录、定向协议/网关/认证/SQLite、前端11项和overlay缺陷探针完成；当前pnpm audit及Go package漏洞扫描单独记录。
- [x] 第一档6簇已实现并填写[验收](../../openspec/changes/archive/2026-10-24-port-upstream-0.2.18-tier1/verification.md)，实施起点`498432759`，两档实现已共同提交为`2b79ac320`。
- [x] 第一档全量unit/build、定向race、真实SQLite结算/dedup/固定窗口通过；前端/依赖未改，无对应pnpm/audit门禁；未发布/部署。
- [x] 第二档S01–S10实现，三agent协作；[第二档验收](../../openspec/changes/archive/2026-10-24-port-upstream-0.2.18-tier2/verification.md)记录最终组合门禁及缺陷/夹具失败；第三/四档保持暂缓/排除。

上一轮通用教训（[0.2.16 §9](./PORTING-0.2.16.md#9-新增通用教训)）：同名功能先核对本地替代调用链；大PR独立修复只补最小基座；缺平台的消费者不当现存缺陷；SSE心跳写出响应需验证失败语义；过期fixture的overlay诊断不等于源码已修；依赖audit重跑并处理pnpm11覆盖位置，例外不自动延期。

v0.2.16历史检查清单：

- [x] 冻结v0.2.12→v0.2.16与fork `128c5f7bf`：149非merge、89PR、4直接提交，575文件先反向后正向四态检查。
- [x] 全部候选分档、最小基座、旧待办与测试首行核对；SQLite/安装/元数据探针和当前依赖audit完成。
- [x] 第一档14簇/第二档16簇OpenSpec计划，覆盖69个本轮PR选定行为；用户明确暂不增加新功能。
- [x] 记录基线通过与失败：定向后端/SQLite、前端242项/typecheck通过；embed两处旧logo用例失败、audit103条记录仍待修。
- [x] 第一档14簇在 `7c544c03f` 完成；第二档16簇已在 `847db09e1` + `5ff6e5bf9` 提交并快进合入 main，见[第二档报告](../../openspec/changes/archive/2026-10-24-port-upstream-0.2.16-tier2/verification.md)。实施验收使用 VERSION 1.1.17、迁移226，依赖定向维护；当前 VERSION 1.1.18 用于发布，未部署业务实例。

上一轮教训（[0.2.12 §9](./PORTING-0.2.12.md#9-新增通用教训)）：payment-only安全修复仍排除；无关依赖子项独立处理；缓存并发/TTL/旧链接必须验收；保留minimum与preferred pin区别；调整档位与tag/VERSION错位须明确记录。

上一轮通用教训（[0.2.11 §9](./PORTING-0.2.11.md#9-新增通用结论)）：同区间可能撤换设计，按目标tag终态排名；CLEAN流处理补丁也可能提前提交HTTP响应；先核实simple模式是否实际启用；模型/套餐元数据与Ultrafast能力按行为拆；旧第四档只有可独立复用子集时，量出基座并明确记录提升范围。

最新评估与历史清单如下。不同轮次可能修改相同文件，**不能假定互不冲突或直接并行应用**。

- [PORTING-0.2.19.md](./PORTING-0.2.19.md) —— **评估完成；第一档7簇已实现并验收，第二档6簇和用户选定第三档Terra仍未实施**。50非merge、20PR+3直接提交，A0/C203/X61/N12；Claude/Codex/Grok优先。保留SQLite227、Go1.27.3、VERSION1.1.20；其它按需能力未选定、支付/缺消费者/PG-only排除。10包定向及邻近回归、61前端测试、隔离缺陷与MVS探针通过，旧遗留当前状态见§5。

- [PORTING-0.2.18.md](./PORTING-0.2.18.md) —— **第一档6簇、第二档10簇已实现**。v0.2.17–v0.2.18，冻结评估为56非merge / 35PR / 8直接提交。第一档验收见[报告](../../openspec/changes/archive/2026-10-24-port-upstream-0.2.18-tier1/verification.md)及[证据](./implementation-0.2.18-tier1/)。第二档含凭据隔离、Responses字段、Codex退休/容量/身份、Anthropic/Gemini断流结算、既有Antigravity/Vertex、图片下载及工具链安全维护，见[验收](../../openspec/changes/archive/2026-10-24-port-upstream-0.2.18-tier2/verification.md)与[证据](./implementation-0.2.18-tier2/)。第二档Go1.27.3需最小x/tools编译前置及强制传递依赖；follow-redirects精确1.16.1，[剩余依赖风险](./implementation-0.2.18-tier2/dependency-review.md)单列。新增能力暂缓，支付排除；最大迁移226；实施验收VERSION1.1.18保持历史值，发布文件已升1.1.19，见[发布说明](../releases/v1.1.19.md)。实现已提交`2b79ac320`，未部署业务实例；旧未合项见§5。

- [PORTING-0.2.16.md](./PORTING-0.2.16.md) —— **第一档14簇已实现；2026-10-18 第二档16簇已提交并合入 main**。第一档在 `7c544c03f` 完成（实施起点 `0fbcab935`），承接40个本轮PR的选定行为，见[验收](../../openspec/changes/archive/2026-10-24-port-upstream-0.2.16-tier1/verification.md)及[实施证据](./implementation-0.2.16-tier1/)。冻结评估仍为149条非merge / 89PR / 4直接提交、A0/C367/X168/N40，两个批次合计69个PR选定行为。重点保留Claude Code/Codex/Grok修复、SQLite结算去重与固定窗口；F10补测后小范围修正既有错误解析helper。第一档实施时 VERSION/迁移/依赖未变。第二档提交为 `847db09e1` + `5ff6e5bf9`，实施验收使用 VERSION 1.1.17/迁移226；发布 VERSION 为 1.1.18，不引入新能力与支付，未部署业务实例。第二档 S16 已定向修复 DOMPurify/axios/Vue/source-map-js，审计103→70，生产high剩xlsx两条；[剩余项](./implementation-0.2.16-tier2/dependency-review.md)和旧待办见PORTING §5。

- [PORTING-0.2.12.md](./PORTING-0.2.12.md) —— **上一轮评估及实施2026-10-02，第一档3簇/第二档3簇完成于`405246789`**。19条非merge、9PR、1直接提交，冻结四态A0/C108/X42/N10。[第一档验收](../../openspec/changes/archive/2026-10-24-port-upstream-0.2.12-tier1/verification.md)：Grok CLI身份、Antigravity脱敏、错误码文案；[第二档验收](../../openspec/changes/archive/2026-10-24-port-upstream-0.2.12-tier2/verification.md)：邮箱原子化及用户确认的账号优先级/密钥排序。补齐旧验证码次数继承和优先级异步归属；全量Go unit/build、定向race、SQLite方言/用量去重/排序，前端typecheck/lint/build与1854通过/2既有跳过。支付两PR/TypeSafe/axios当轮排除，VERSION 1.1.15、迁移226不变，未发布/部署。历史遗留见最新§5。

- [PORTING-0.2.11.md](./PORTING-0.2.11.md) —— **上一轮，2026-09-30，第一档4簇与第二档6簇开发验收完成**。改动在 `sync/upstream-0.2.11` 分支，基线 `f13dee245` / v1.1.14。[第一档验收](../../openspec/changes/archive/2026-10-24-port-upstream-0.2.11-tier1/verification.md)与[第二档验收](../../openspec/changes/archive/2026-10-24-port-upstream-0.2.11-tier2/verification.md)记录全量Go unit/build、定向race、SQLite和前端1836通过/2既有跳过、typecheck/lint/build。包含旧0.2.9 F04两桥前置与695ebede7仅14行通用usage字段；采用#7736最终目录设计。VERSION仍1.1.14，最大迁移226，无依赖变更；第三/四档及Astra Ultrafast未引入，已按用户要求完成本地Docker及远端部署并通过健康检查，未发布Release。

- [PORTING-0.2.9.md](./PORTING-0.2.9.md) —— **历史评估2026-09-28；两档均已完成归档**。第二档48PR/16簇在 `159d04222` 落地，其[实施验收](../../openspec/changes/archive/2026-10-24-port-upstream-0.2.9-tier2/verification.md)保留原有后端、SQLite、前端及浏览器证据。第一档39PR/15簇于2026-10-24由用户明确确认完成，见[完成确认记录](../../openspec/changes/archive/2026-10-24-port-upstream-0.2.9-tier1/completion-record.md)与归档前任务/验收快照。冻结的215条非merge、161PR、四态和来源SHA保留历史值，旧待实施描述按本次完成确认更新当前状态，不回写原始评估。

- [PORTING-0.2.4.md](./PORTING-0.2.4.md) —— **历史轮次，2026-09-12，第一档13项、第二档12簇已落地 main，最终构建和总检查通过**。两份 OpenSpec 的任务和验收已回填；[最终验收](./evidence-0.2.4/implementation.md)记录54包后端 unit、240文件/1720项前端测试、静态单文件构建及真实 SQLite/浏览器验证，并追加 API Key Responses namespace 修复及其定向验证。初始151条提交、114候选、1,044条四态证据保持冻结。VERSION仍为1.1.11，迁移仍为226，SQLite/miniredis/simple mode保留。第三/四档与旧DOMPurify独立待办未实施；本次未创建新 tag 或 Release。

- [PORTING-0.2.0.md](./PORTING-0.2.0.md) —— 上游 v0.1.185 + v0.2.0（2026-09-02，历史轮次）。60 个非 merge commit，11 项 P0 与 4 项 P1 主体已落；两个 change 为 [`port-upstream-0.2.0-p0-fixes`](../../openspec/changes/archive/2026-10-24-port-upstream-0.2.0-p0-fixes) 与 [`port-upstream-0.2.0-p0-tail-and-p1`](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.0-p0-tail-and-p1)，已于 `c9d9bebe8` 合回 main。新迁移为 `225` 推理档位与 `226` 渠道 1h 缓存价。第二档阶段 9 DOMPurify 由 S16 / `5ff6e5bf9` 接管；剩余类型桩清理、四处真实浏览器验收和完整门禁/SHA 回填于 2026-10-27 完成，提交 `5b3e1a716`，任务为 128/128，见[收尾验收](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.0-p0-tail-and-p1/verification.md)；旧 §5.4 API Key instructions 已在 0.2.4 重新核实并提升为 F13，其余未合项以最新 §5.3 盘点为准。历史 source-baseline 与当时验证记录不改写。
- [PORTING-0.1.184.md](./PORTING-0.1.184.md) —— 上游 0.1.184 大混合版（2026-08-31）。**§3 的 14 项 P0 与 §4 的 11 项 P1 已全部合入**（实施记录见其 §9 / §11 / §13，验证矩阵见 §10 / §12 / §13.4）。上游 3 条新迁移全部不合，故本仓库迁移号仍是 224。**§5.1 Codex routed model catalog 整簇也已合入**（立项见 §14，落地与剔除见 §15）。**§5.7 Antigravity 混合内置工具也已合入**（其「基座」其实只是两条 ≤ v0.1.183 的漏项，见 §16）。剩下的是 §4 那组「取决于是否用到该功能」的按需项 + §5 余下五簇。⚠️ 其 §1 那句「上游 main `200602b41` 之后 3 条本文不含」说的是**该文档的覆盖范围**，不是「本仓库没有」——`e2624fb65` 实际已随 §5.1 落地，见 0.2.0 §6 / §9.1。
- [PORTING-0.1.183.md](./PORTING-0.1.183.md) —— 上游 0.1.181 / 0.1.182 / 0.1.183 三个纯 bugfix 版。**全部合完**：§3 的 12 项 P0、§4.1（监控 v2 composite，见 0.1.184 §25）、§4.2、以及原判「缺基座不做」的 §5.1 Responses Lite 簇（更正见 0.1.184 §17–§18）。
- [PORTING-0.1.180.md](./PORTING-0.1.180.md) —— 上游 0.1.180 大混合版。**§5 的 19 项 P0、§6.2 / §6.3 的决策与小项、§6.1 的 4 条工具桥接修复已合**；仍未做的是 §6.1 剩余 4 条、§6.2(c) Grok 稳定性整簇、§7 的四个大功能。上面那份里的 Responses Lite 簇要等 §6.1 的 `7498d8fdc` 与 §7.1。0.2.0 §5.2 那簇（长上下文阶梯数据驱动）的 573 行基座就是这份 §7 未合的那一支。**§5.1 dompurify 已于 2026-09-02 重新量过、改判「建议做」并曾并入 0.2.0 第二档作为阶段 9（见其 §12）**，但第二档实施时按目标 **未改 lockfile，故仍未合**：3 个文件 / 22 行 lockfile / 零代码改动，一次可清掉 18 条 advisory；同时更正了原判两处判据（暴露面是 7 个净化调用点而不是 1 个，其中 `/legal/*` 完全公开；原清单唯一引用的那条 CVE 用四种污染形态都没能复现）。量的时候还撞见两条不在任何清单里的直接依赖 high：`xlsx` 原型污染 + ReDoS（运行时，无干净升级路径，值得单独立项）与 `vite` / `vitest` 的 dev-only 项。 **后续状态补记（2026-10-27）**：该 DOMPurify 计划已由 0.2.16 第二档 S16 / `5ff6e5bf9` 接管升级；0.2.0 收尾的类型桩、四处浏览器和完整门禁也已完成，见[当前验收](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.0-p0-tail-and-p1/verification.md)。前述旧版本、未合判断和 22 行方案保留历史口径。

**0.2.5 后续收尾（2026-10-28）**：S12b 平台限额清理与 SQLite 迁移227已完成，包含只保存已配置/保留0、不复活软删记录、窗口兼容读取和前端卡片/重置语义。S02 #7043的独立决策保留默认1.0，不采用数值5.0；其容量公式修复保持已完成。当前任务33/33，完整门禁通过，见[验收](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.5-tier2/verification.md)。其它 #6960/#7049、#7237/#7289 与支付范围没有因此纳入；旧评估中的预留227/未实施判断仍按历史日期解释。

两份的 P0 都已固化为 OpenSpec change：[`port-upstream-0.1.183-p0-fixes`](../../openspec/changes/archive/2026-10-24-port-upstream-0.1.183-p0-fixes)（12 项）与 [`port-upstream-0.1.180-p0-fixes`](../../openspec/changes/archive/2026-10-24-port-upstream-0.1.180-p0-fixes)（19 项交付 + 2 项推迟）。行为契约与验收看 change，逐条 patch site 看这两份 PORTING 文档。

`openspec/changes/` 的历史活动变更已无未完成任务：0.2.0第二档于2026-10-27完成128/128项，0.2.5第二档于2026-10-28完成33/33项（实现 `b349c7408`、迁移227，WS默认保留1.0），两者保留活动目录等待后续归档；具体任务计数与保留原因见[归档清单](../../openspec/changes/archive/README.md)。此外，本次用户选定的个人功能change已开发验收，实现已提交为`0e38d06d8`，保留在活动目录等待后续归档。已归档批次的行为契约汇总于[主规格](../../openspec/specs/)，实施证据仍在各档案中。新一轮的立项规则见 [AGENTS.md](../../AGENTS.md) 的「Upstream release intake」：第一档/第二档按流程立change，第三档/第四档须先获用户选定；本次授权不扩展到其他按需能力。

两批 P0 之后的下一批是 [`resolve-pending-decisions-and-p1-fixes`](../../openspec/changes/archive/2026-10-24-resolve-pending-decisions-and-p1-fixes)：4 项 P1（依赖审计例外过期、Grok 目录计费、调度 veto 诊断、真实上游端点）+ 3 个决策一次性拍板（Grok 默认 4.6 / Go 1.27 / 长上下文门控改 OR）。

再下一批是 [`port-upstream-p1-tool-bridge-and-composite-dispatch`](../../openspec/changes/archive/2026-10-24-port-upstream-p1-tool-bridge-and-composite-dispatch)（2026-08-28）：从剩余 backlog 里挑 6 条「缺陷已核实、patch site 对得上、彼此无文件冲突」的候选，**实际交付 5 条**——0.1.180 §6.1 的 4 条工具桥接修复（PDF 附件静默丢弃、流式 tool_call 空身份、HTTP bridge 重复回放与孤儿 tool call）+ §6.3 的 composite `/v1/messages` 闸门。第 6 条 `17c0ee385` 在实施中被证实是 **`apply --check` 干净的 no-op**（依赖同簇未合的 `953028718`）并撤回——这是本仓库遇到的**第四种假信号**，详见该 change 的 `design.md` 决策 7 与 `source-baseline.md` §3。

上一轮 [PORTING-0.1.179.md](./PORTING-0.1.179.md)，P0/P1 已全合；再上一轮 [PORTING-0.1.176.md](./PORTING-0.1.176.md)，标题写 0.1.177，已全合。

[PORTING-0.1.184.md](./PORTING-0.1.184.md) 那轮添了三条通用教训，移植前值得先看：

- **`apply --check` 干净 ≠ 能编译/能跑**，那一轮抓到三条（0.1.184 §2 与 §11.1）。判定方法不是看三态，而是对新增代码里的每个函数调用逐个 grep 基座是否存在。**前端同样成立**：`ed12ea716` 六文件全干净却直接 `escapeTomlBasicString is not defined`，而 `pnpm run typecheck` 抓不到 —— 移植前端必须真跑 vitest。
- **逐条 cherry-pick 会落在上游的中间态。** 同一个函数的签名、同一条用例的入参，可能在区间里更靠后的提交又改过一次（0.1.184 §9.3 / §11.3）。移植前先 `git show <tag>:<file>` 看终态，再决定按哪一版落；也要留意「看着该跟着改、上游其实刻意没改」的地方。
- **「缺基座」要顺着符号往上游历史回溯一层，先量基座本身有多大**（0.1.184 §16）。零命中只说明「现在做不了」，不说明「做起来贵」——§5.7 当初按零命中归入不做，实际基座是两条各百行以内、都能干净落地的漏项。按这条回头量了剩余全部「缺基座」判断，**四处全部低估**（0.1.184 §17）：`decodeOpenAIJSONUseNumber` 是 24 行 stdlib-only 独立文件、`IsOpenAIOAuthLike` 是 3 行谓词、§5.2 的基座约 50 行。0.1.183 §5.1 Responses Lite 簇由此重新可做。
- **基座要随用它的簇一起移植**，不要为了「先补齐」单独落一个没人调用的函数（0.1.184 §17.2）——那是死代码。免费的基座是「解锁条件已满足」的信号，不是「可以先合」的许可。
- **backlog 里挂最久的项，往往是最早被贴上标签、之后再没人量过的那个**（0.1.184 §25）。「需 SQLite 重写」「缺基座」这类标签一旦写下就被后续每一轮沿用。定期回头量一遍最老的几项，比继续往前找新项划算——0.1.183 §4.1 从第一天挂到最后，量完只是约 10 行 SQL。
- **SQL 常量的注释里不要写 PG 语法字面量**，哪怕当反例——`sqlite_dialect_audit_test` 连注释一起扫（0.1.184 §25.2）。
- **用例整取之后仍可能有个别子用例越界**（0.1.184 §23.1）。第 13 条的 grep 保证「能编译」，保证不了「断言的都是本条改的行为」。子用例失败时先问「这条断言的是本条改的东西吗」，再决定补基座还是删用例。
- **同一条规则在本仓库的另一条路径上可能已经写对了**（0.1.184 §22.2）。移植前 grep「这个语义在别处怎么处理」，既能确认缺陷真实存在，也能拿到现成的判定写法——`c83dced4b` 那条 WARN 一边打印 `close_status=1000` 一边把错误算到账号账上，日志里就写着答案。
- **「测试文件 apply 干净」不等于「测试能编译」**（0.1.184 §21.2）。三态是按文件报的，测试文件通常无冲突，很容易被记成「测试没问题、只差产品代码」——`f4e3eb1c5` 的两个用例就是 apply 干净但引用了未移植的符号。判定方法同第一条：对用例引用的符号逐个 grep。
- **试落时如果只有测试文件干净、产品代码全冲突，立刻撤回测试文件**（0.1.184 §20.2）。留着会得到「编译通过但用例必然失败」的状态，比没开始更糟，下一轮还容易误以为已合。撤回时把每个产品 hunk 的行数量下来，下一轮照表手工对齐。
- **移植基座之后 grep 一遍谁还在用被它取代的旧写法**（0.1.184 §20.1）——`decodeOpenAIJSONUseNumber` 落地后发现 `prepareOpenAIWSHTTPBridgeBody` 还在用 `json.Unmarshal` 静默丢大整数精度，这个缺陷不在任何清单里。
- **「缺基座」和「本 fork 架构上不需要」要分开归类**（0.1.184 §19.3）。判据是看那个基座为什么存在——如果它存在的理由是多实例协调（Redis 租约、leader 锁、跨节点广播），单节点 fork 大概率是永久不做，不是等排期。§5.4 的 `d5a012463` 就是这样从「缺基座」改判为按需/N/A 的。
- **基座便宜 ≠ 功能该做。** §5.2 的基座约 50 行，但它服务的 §7.2 Fast mode `service_tier` 整个功能是 25+ 文件 / +1584，且只有真在发 fast / priority 请求才划算。两件事要分开判。
- **上游修复只覆盖了它自己的那条调用点，本 fork 的主路径可能是另一条。** 0.1.184 §3.4（Fable OAuth 系统提示词）就是样本：上游只改了桥接路径的注入点，原生 `/v1/messages` 的注入点在另一个文件，而后者才是本 fork 的主用法。照抄 patch 会得到一个「合了但没修好」的结果——这是第 13 条空转陷阱的变体，**核查时要问「这个函数被谁调用」，不只是「这个 patch 能不能打上」**。

[PORTING-0.2.0.md](./PORTING-0.2.0.md) 那轮（v0.1.185 / v0.2.0）又添六条，详见其 §9：

- **开轮先跑一遍反向 `apply --check`（`ALREADY` 态），三态改四态。** 「某份 PORTING 文档不含」≠「本仓库没有」——上一轮的对照上游 main 可能已在下一个 tag 内部，且按终态取文件时会顺带落进邻近提交。本轮 `e2624fb65` 三文件全 `ALREADY`，直接省掉一次重复移植。
- **上游把一个功能拆成十几条微提交时，逐条判定是噪声。** 要按 PR merge 取整体 diff（`git diff <merge>^1 <merge>`）。同一个 PR#6443 逐条看是一片冲突，整体看是 38/44 干净。
- **链上的冲突数不是工作量，排序前不要报数。** PR#6444 的 30 处、PR#6425 的 9 处 CONFLICT 全部只因前一条未落。
- **`CONFLICT` 也可能是「缺基座 / 无此缺陷」的伪装。** 凡 CONFLICT 都要先 grep 被改函数在不在，再判「手工改」还是「不成立」——`343858021` 就是后者，本仓库没有 `classifySelectionFailureError`，也就没有那个 bug。
- **一个 PR 里可能塞两件不相关的事，按功能拆而不是按 PR 合。** `34b8bf1a6` 标题只说 Fable 5.1，一半内容是带迁移的渠道 `cache_write_1h_price` 拆分。**看到 PR 里出现迁移文件而标题没提，就先拆。**
- **「上游为 X 修的」不代表「本仓库因 X 受益」，但结构收益仍可能成立。** 平台 N/A 时先看它顺手修掉的结构问题在不在（`9eabd2a5b`）。
- **安全项要单独拎出来问，而且要重量而不是重述。** 判据里「输入可信」和「受众范围」是两件事——净化跑在**访问者**的浏览器里；清单引用的 CVE 未必被验证过，安全项的「已核实」标准比功能项高一档（功能项 grep 到 patch site 即可，安全项还需要能跑的 PoC）。没有 PoC 时理由要换成可验证的那些（advisory 数量、调用点数量、暴露面）。样本：0.1.180 §5.1 → §12。
- **`_integration_test.go` 落地前先 `head -1` 看构建标签。** 本仓库有一批是 `//go:build integration && postgres`，在 SQLite-only fork 里永远不编译（`internal/repository/migrations_schema_integration_test.go` 就是，而上游 PR#6443 / PR#6444 改了它）。这类 hunk 无论三态报什么都直接丢，**不要为了让它能打上去动构建标签**。

[PORTING-0.2.4.md §9](./PORTING-0.2.4.md#9-本轮新增教训) 补充：

- **按 tag 祖先统计增量，不能只看 Release 列表或作者日期。** v0.2.2 有 tag，仍需覆盖。
- **profile 定义、getter、消费者齐全还不够，要有生产 setter。** #6281 新 LongStream profile 没有生产接入点；本 fork 原有 OpenAI H2 已启用 PING。
- **用独立 index 固定四态，用户工作树修复单独记。** ALREADY 是文件证据，语义已合还需追调用链。
- **缺 helper 要量函数体，原定级变化明确写出。** API Key instructions 的缺口为 3 行，日志默认值 helper 为 7 行。
- **miniredis 仍使用 go-redis 客户端；Ultra reasoning 与 Ultrafast service_tier 不同。** 名称相似不能代替功能链核查。
- **共享正文与 fail-open 需要专门验证。** 补丁可应用不代表所有权、CAS 或 snapshot 时序正确。
- **整 PR 中也可能混入其它功能测试。** #6743 的兑换测试和 #6536 的外网 token 测试要排除。
- **保留安全审计日期与证据边界。** 旧 advisory 数不是今日结果，新可选下载功能的 SSRF 修复不等于本 fork 已有漏洞。

移植上游代码前先读 [第 4 节「硬约束」](#4-硬约束)，尤其是 9–12 条（SQLite 适配的四个静默陷阱）与第 13 条（守卫类单行改动的空转陷阱）。这几条的由来见 [第 7 节的事故复盘](#7-案例一次由-sqlite-适配引发的调度事故2026-08-16)。

[PORTING-0.2.9.md §9](./PORTING-0.2.9.md#9-本轮可复用的结论) 补充：上游参数回退前先核对fork是否受影响；文档删除的ALREADY不代表业务已合；原生Codex与CC Switch的URL规则分开验证；调度投影字段必须确认对应后台功能已接线。旧verification里的“未提交”要与实际commit交叉核对，不改写冻结历史。

写 / 改 SQL 时对照 [第 5 节「PG → SQLite 转换速查」](#5-pg--sqlite-转换速查)。上一次 PG 残留核查的结论与复查命令：[PG-REMNANTS-AUDIT.md](./PG-REMNANTS-AUDIT.md)（2026-08-16，基线 `a8ccd19`）。

---

## 1. 仓库关系

| Remote | 地址 | 用途 |
|--------|------|------|
| `origin` | 本 fork（例如 `git@github.com:githubliangliang/sub2api.git`） | 日常推送 |
| `upstream` | `git@github.com:Wei-Shaw/sub2api.git` | 只读拉上游 |

HTTPS 拉上游容易 TLS 中断，用 **SSH**。

```bash
git remote add upstream git@github.com:Wei-Shaw/sub2api.git   # 已有则跳过
git fetch upstream --tags
```

看上游新了什么：

```bash
git log --oneline --decorate upstream/main -30
git log --oneline HEAD..upstream/main | head -50
```

本仓库历史是 squash 过的，`HEAD..upstream/main` **不能**当成「本仓库缺的提交列表」。要以「本仓库有没有这个功能」为准，见 [PORTING-0.1.180.md](./PORTING-0.1.180.md) 的基线对照（判定手法见其第 2 节）。

---

## 2. 为什么不能整仓 merge

相对上游，本 fork 已经改了很多：

- 只支持 SQLite，`backend/migrations/*.sql` 是 SQLite 方言
- Redis 可关（进程内 miniredis）
- 菜单隐藏、simple mode、用量落库
- 去掉残留 PostgreSQL 路径

直接 `git merge upstream/main` 几乎找不到共同祖先，会把两边当成两套无关历史硬撞，并容易把已删的 PG 代码、PG 迁移、SaaS 页面带回来。

**这个 fork 只适合 cherry-pick / 手工移植。**

---

## 3. 推荐流程

### 3.1 先看发布说明，再看提交

| 值得合 | 通常不要合 |
|--------|------------|
| 网关 / 调度 / failover bugfix | PostgreSQL 迁移、分区、`pg_dump` |
| 新模型 / 新平台适配 | 多实例 Redis、SaaS 计费 |
| 安全修复 | 已删页面、支付、ops 大功能 |
| 前端小修复（不依赖被删页面） | 把 `database.driver=postgres` 加回来的改动 |
| 与「用量落库」同向的计费修复 | 备份分卷、leader 锁（单机 SQLite 用不上） |

上游发布页：<https://github.com/Wei-Shaw/sub2api/releases>

### 3.2 开同步分支

```bash
git switch -c sync/upstream-$(date +%Y%m%d) main
```

### 3.3 一颗一颗挑，或按功能手工移植

独立、文件少的 bugfix：

```bash
git show <upstream-sha> --stat
git cherry-pick <upstream-sha>
```

大功能（新模型、新字段、新端点）优先 **按文件移植**，不要 cherry-pick 整个 merge commit：

- 上游 PR 常带生成的 `backend/ent/*`，这边只改 `ent/schema` 再 `go generate`
- 上游迁移是 PostgreSQL，这边要 **新建** SQLite 迁移
- `group_repo.go` 等在本 fork 是手写 SQLite SQL，不能整文件覆盖

冲突了先看文件属于哪一类：

| 类型 | 处理 |
|------|------|
| 业务逻辑（`internal/service`、`internal/platform`、gateway handler） | 值得解 |
| `backend/migrations/*.sql` | 转 SQLite 后 **新建** 文件；不要改已应用文件 |
| Ent schema | 改 schema → `go generate ./ent` |
| 本 fork 特有文件 | 优先保留这边：`REFACTOR.md`、`deploy/config.personal.sqlite.yaml`、`EnsureSQLiteAuxTables`、simple mode / hidden menu |

```bash
git add -A
git cherry-pick --continue
# 或
git cherry-pick --skip
git cherry-pick --abort
```

### 3.4 自测再合回 main

```bash
cd backend && go test -tags=unit ./...
cd ../frontend && pnpm run typecheck && pnpm exec vitest run
```

重点盯：

- 登录 / `user_allowed_groups`（缺表会 503）
- 用量写入（`usage_billing_dedup`）
- 调度冷却、账号 failover
- 新迁移能否在现有 SQLite 上跑

---

## 4. 硬约束

1. **不要把 PostgreSQL 路径合回来。** 运行时只开 SQLite。
2. **迁移只增不改。** 已应用的 `*.sql` 改内容会 checksum 失败。个人环境可以删 `*.db` 重建，已有库不行。
3. **上游新迁移先转 SQLite。** `backend/scripts/pg_sql_to_sqlite.py`，逐条对照 [第 5 节的转换速查](#5-pg--sqlite-转换速查)。PG 专属特性（分区、`trgm`、`plpgsql`、`COMMENT ON`、`CREATE EXTENSION`）改写成 SQLite，或继续 `SELECT 1` no-op。**动手前先看 5.1**——`$N` 占位符、`RETURNING`、`IS DISTINCT FROM`、窗口函数 `PARTITION BY` 等一大批构造 SQLite 本来就支持，改了纯属白费功夫还容易引 bug。
4. **迁移编号以本仓库为准。** 上游文件名可能和这边已占用的序号冲突（例如上游 `221_group_model_pricing.sql`，这边 `221` 已是 affiliate）。
5. **Go 版本。** 当前CI与 `backend/go.mod` 均为 `1.27.3`。上游升 Go，要同时改 go.mod 和 workflow；历史版本记录不回写。
6. **前端用 pnpm。** 合了 `package.json` 必须提交 `frontend/pnpm-lock.yaml`。
7. **改 interface / Ent schema 要改测试 stub，并 generate。**

```bash
cd backend
go generate ./ent            # schema 变更后
go generate ./cmd/server     # 动了 wire.go
```

不要手改 `wire_gen.go`，不要抄上游生成的 `backend/ent/group*.go`。

8. **bcrypt / `$`。** 写 SQL 或脚本用文件，不要在 shell 里直接贴哈希。

9. **「适配 SQLite」不等于「把服务关掉」。** `skipSQLiteBackgroundJobs`（`internal/service/wire.go`）会跳过整个后台服务的 `Start()`。判断依据必须是**这个服务的 SQL 是不是 PG 专属**，而不是「我们在跑 SQLite」。关错的代价是静默的：服务不启动 → 不报错 → 功能悄悄失效，直到某天现象离根因十万八千里（见第 7 节）。

   遇到上游服务在 SQLite 上报错，正确顺序是：**先看错在哪一条 SQL** → 能改方言就改方言 → 确实是 PG 专属特性（`COPY`、分区、`plpgsql`、advisory lock）才考虑跳过。跳过时在代码里写清楚**跳过的是哪条 SQL**，不要只写「SQLite 不支持」。

   当前状态（2026-10-28）：`UsageCleanupService`、`AccountExpiryService`、`ScheduledTestRunnerService` 已逐SQL适配并恢复，旧TEXT扫描/混合时间比较、取消/停止/重叠和结果持久化已验收，见[个人维护证据](../../openspec/changes/archive/2026-11-01-port-upstream-0.2.18-personal-maintenance/verification.md)。下文事故记录及旧 `skipSQLiteBackgroundJobs` 名称是历史，不能再据此关闭服务。

10. **`EnsureSQLiteAuxTables` 的 DDL 必须和迁移文件逐列一致。** 两边都是 `CREATE TABLE IF NOT EXISTS`，**谁先跑谁定型**，而 aux 表通常先跑。一旦列类型不一致，现网库以 aux 表为准，迁移文件里的定义完全是死的，看代码会被误导。

    移植上游新表时：加迁移的同时检查 `sqlite_aux_tables.go` 有没有同名表；两边都要建就让 DDL 完全一致。**改 aux 表的列类型只对新装库生效**，已有库不会重建——需要为存量库单独写迁移，或让读取端兼容两种形态。

11. **读 SQLite 的时间列要类型无关。** `modernc.org/sqlite` 对 `TEXT` 列返回 `string`，对 `DATETIME` 列才返回 `time.Time`。直接 `rows.Scan(&t)`（`*time.Time`）扫一个历史上被建成 `TEXT` 的列，会每次都报 `unsupported Scan, storing driver.Value type string into type *time.Time`。存量库的列类型不由你的代码决定，所以**读取端要兼容两种**（参考 `scanSchedulerOutboxTime`）。这条是 AGENTS.md「时间戳用 DATETIME」的延伸：写入端约定管不住已经建错的存量库。

12. **去重（dedup）语义不能默认消费者活着。** `INSERT ... ON CONFLICT (dedup_key) DO NOTHING` 的隐含前提是「冲突的那行马上会被消费掉」。消费者一旦停摆，滞留行的 `dedup_key` 就永久占位，**后续同 key 的新事件在入队处被静默吞掉**——没有报错、没有日志，只有功能不生效。

    本仓库改成了**先删后插**：待处理的重复仍然合并成一条，已消费/滞留的旧行不再挡路，正确性不再依赖水位状态。移植上游任何 outbox / 事件表时按同样标准审一遍。

13. **守卫类单行改动，要连同它守卫的下游判定一起验证。** 一条 patch 只放宽某个 `if` 的状态码集合 / 平台白名单 / feature flag 时，它放行的路径下游通常还有第二道判定。上游那道判定往往已被**同簇的另一条 commit** 一并放宽，本仓库若没合那条，就是**外层放开、内层照否**，净行为为零。

    危险之处在于这类改动**看起来最安全**：一行、无冲突、不引用新符号、`apply --check` 干净、编译通过、测试全绿——最容易被当成「顺手捡的小修复」合进来，然后在移植清单上留下一条「已支持 X」的假记录，下次排查时反而误导人。

    合之前先回答：**「改完之后，什么样的真实输入会走到新放行的分支里，并且真的产生不同结果？」** 答不上来就是 no-op，不要合。机械核法是把 patch 里新放行的每个状态码 / 枚举值，拿到**上游同版本的完整文件**里再 grep 一遍，确认下游判定也认这个值：

    ```bash
    curl -sSL "https://raw.githubusercontent.com/Wei-Shaw/sub2api/<上游tag>/<path>" | grep -n '<新放行的值>'
    ```

    实例：`17c0ee385`（Grok compaction 422 同号重试）。详见 [PORTING-0.1.180.md](./PORTING-0.1.180.md) 第 2 节「第四种假信号」、§6.2(c) 与 §10，以及 [`port-upstream-p1-tool-bridge-and-composite-dispatch`](../../openspec/changes/archive/2026-10-24-port-upstream-p1-tool-bridge-and-composite-dispatch) 的 `design.md` 决策 7。

---

## 5. PG → SQLite 转换速查

移植上游 SQL（迁移、手写 raw SQL）时对照本节。**下表全部在本仓库实际运行时验证过**：`modernc.org/sqlite` 内置 SQLite **3.51.2**，比多数「SQLite 不支持 X」的网上说法新很多。

自动转换器：`backend/scripts/pg_sql_to_sqlite.py`。它只处理常见模式，复杂逻辑仍要人工过一遍。

### 5.1 不用改 —— 常被误判成「SQLite 不支持」

改这些等于白费功夫，还容易在改写中引入 bug：

| 构造 | 说明 |
|------|------|
| `$1` / `$2` 占位符 | **SQLite 原生参数语法**，不是 PG 残留。全仓大量使用，不要改成 `?` |
| `RETURNING` | 3.35+ |
| `ON CONFLICT (a,b) DO UPDATE SET x = excluded.x` | 标准 UPSERT |
| `ON CONFLICT (a,b) WHERE cond` | 部分索引推断，支持。**前提是那个部分唯一索引真的存在**，否则运行时报错 |
| `OVER (PARTITION BY ...)` 窗口函数 | 支持。别和 PG 的**表分区** `PARTITION BY RANGE` 混为一谈——后者才要改写 |
| `IS DISTINCT FROM` | 3.39+。硬约束第 3 条里曾把它列为需改写，已过时 |
| `string_agg(x, ',')` | 3.44+。`group_concat` 也可用 |
| JSON `->` / `->>` | 3.38+ |
| `json_extract` / `json_set` / `json_patch` | 支持 |
| `TRUE` / `FALSE` 字面量 | 3.23+ |
| 递归 CTE `WITH RECURSIVE` | 支持 |
| 单对象 `CREATE TABLE/INDEX IF NOT EXISTS` | 支持（`ALTER TABLE ADD COLUMN IF NOT EXISTS` 不支持，见下） |
| `NOW()` / `GREATEST` / `LEAST` / `TO_CHAR` / `HOST` | **本仓库自己补的兼容函数**，见 `sqlite_pg_compat.go`（清单与调用点见 [PG-REMNANTS-AUDIT.md](./PG-REMNANTS-AUDIT.md)）。原样保留即可，但注意 `NOW()` 返回 RFC3339Nano **字符串**（带 `Z`），和 `CURRENT_TIMESTAMP` 格式不同；`TO_CHAR` 只实现 4 种格式串 |

### 5.2 必须改写

| PG | SQLite | 备注 |
|----|--------|------|
| `ILIKE` | `LIKE` | LIKE 对 **ASCII 默认不区分大小写**，见 5.3 |
| `x::type` | `CAST(x AS type)` | |
| `DATE_TRUNC('day', ts)` | `date(ts)` / `strftime('%Y-%m-%d', ts)` | |
| `EXTRACT(YEAR FROM ts)` | `strftime('%Y', ts)` | 返回字符串，需要数字要 `CAST` |
| `ts + INTERVAL '7 days'` | `datetime(ts, '+7 days')` | |
| `AT TIME ZONE` / `TIMESTAMPTZ` | `DATETIME` + 应用层处理 | |
| `DISTINCT ON (a)` | `ROW_NUMBER() OVER (PARTITION BY a ORDER BY ...)` 外层过滤 `rn=1` | |
| `FOR UPDATE` / `SKIP LOCKED` | 删掉 | SQLite 单写者，靠事务本身串行 |
| `pg_advisory_lock()` | 应用层 mutex | 参考 `TryAcquireCleanupLock` |
| `= ANY(ARRAY[...])` | 展开成 `IN (?,?,...)` | 用 `sqlInt64In` 生成占位符 |
| `array_agg` / `unnest` / `ARRAY[...]` | `group_concat` / JSON 数组 | |
| `COPY t FROM STDIN` | 事务内批量 `INSERT` | |
| `information_schema.tables` | `sqlite_master` | |
| `SERIAL` / `BIGSERIAL` | `INTEGER PRIMARY KEY AUTOINCREMENT` | |
| `ALTER TABLE ... ADD COLUMN IF NOT EXISTS` | 直接 `ADD COLUMN`，**吞掉 duplicate column 错误** | SQLite 无此语法 |
| `CREATE INDEX CONCURRENTLY` | 去掉 `CONCURRENTLY` | |
| `COMMENT ON ...` | 删掉 | |
| `DO $$ ... $$` / plpgsql / 触发器函数 | 改写成普通 SQL，或 `SELECT 1` no-op | |
| `CREATE EXTENSION` / `trgm` / `tsvector` | `SELECT 1` no-op，或换 `LIKE` / FTS5 | |
| `gen_random_uuid()` | 应用层生成 | |
| `PARTITION BY RANGE` 表分区 | 单表 + 索引 | |

### 5.3 最危险的一类：语法通过，语义不同

这类**转换器和 `TestProductionSQLUsesSQLiteDialect` 都抓不到**，只有在真实数据上跑才会暴露：

- **`jsonb_set` 之类不会报「函数不存在」。** SQLite 3.45+ 已有 `jsonb_*` 函数，但路径语法是 `$.k` 而不是 PG 的 `{k}`。报错会是 `bad JSON path`，甚至在某些写法下悄悄返回别的结果。**看到 `jsonb_` 一律改成 `json_` 并改写路径**。
- **`LIKE` 的大小写规则是分裂的**：ASCII 不区分大小写（`'xy'` 匹配 `'Xy'`），非 ASCII **区分**（`'мир'` 匹配不到 `'Мир'`，`'äbc'` 匹配不到 `'ÄBC'`）。从 PG 的 `ILIKE` 改过来时，含非 ASCII 的搜索行为会变。
- **列类型是「建表时谁先跑谁说了算」**，不是代码说了算。声明 `DATETIME` 但库里实际是 `TEXT` 时，写入不报错、读取才炸。见硬约束 10、11。
- **SQLite 是动态类型**：往 `INTEGER` 列写字符串不会报错。PG 上靠列类型兜底的假设在这里不成立。
- **布尔存成 0/1**，`SELECT ... WHERE flag` 行为和 PG 的 `boolean` 有差异。
- **`datetime('now')` 是 UTC**，而 Go 写入的 `time.Time` 可能带本地时区。同一张表混进两种格式，排查时会得出完全相反的时间线结论（第 7 节踩过）。

### 5.4 一个有用的诊断信号

`AUTOINCREMENT` 主键在 `ON CONFLICT ... DO NOTHING` 命中冲突时**仍然消耗 id**：

```
INSERT k='a'                    -> id=1
INSERT k='a' ON CONFLICT DO NOTHING  -> 无行，但 id=2 被吃掉
INSERT k='b'                    -> id=3
```

所以**表里 id 跳号 = 有多少次插入被 `DO NOTHING` 静默吞掉**。第 7 节那次事故里，`scheduler_outbox` 的 id 空洞正是被吞事件的计数。查「事件为什么没落库」时，先看 id 连不连续。

### 5.5 验证手段

```bash
# 静态：扫 internal/ + cmd/ 所有字符串字面量里的 PG 专属语法（24 类模式）
go test ./internal/repository/ -run TestProductionSQLUsesSQLiteDialect -count=1
```

这个测试能拦 5.2 的大部分，但**拦不住 5.3**。改完 SQL 一定要在真实（或复制的）库上跑一遍，别只靠单测里的临时建表——临时表的列类型是你自己写的，正好绕开了最容易出问题的那一类。

---

## 6. 日常节奏

```text
偶尔     git fetch upstream
         看 releases / git log upstream/main

有用的修  cherry-pick 到 sync 分支 → 测 → 合 main
大功能    先看 PR 文件列表，按 PORTING 文档移植
整仓 merge  不要做
```

每合完一轮，更新 [PORTING-0.1.180.md](./PORTING-0.1.180.md) 的状态列，或新开 `PORTING-<tag>.md`。

---

## 7. 案例：一次由 SQLite 适配引发的调度事故（2026-08-16）

修复提交 `c35a482`。放在这里是因为**根因全部出在 fork 的 SQLite 适配上**，移植上游时最容易再次种下同类问题。

### 现象

后台把一个健康账号重新启用后，**开启永远不生效**，请求一直报：

```
no available OpenAI accounts supporting model: gpt-5.6-sol (pool=2, eligibility_empty)
```

数据库里该账号 `schedulable=1`、模型映射齐全、分组正确、配额/限流/过期全干净——**看库完全正常**。重启进程后恢复，过一阵又复发。

### 五层叠加的根因

| # | 根因 | 为什么难查 |
|---|------|-----------|
| 1 | `skipSQLiteBackgroundJobs` 把 `SchedulerSnapshotService.Start()` 整个跳过，outbox poller 和 300 秒全量重建在 SQLite 上从不运行 | 服务没启动就不会报错，**日志里一条调度相关的行都没有** |
| 2 | 即使启动，poller 首轮就死：`scheduler_outbox.created_at` 是 `TEXT` 列（aux 表先建，迁移 036 的 `DATETIME` 被 `IF NOT EXISTS` 空转），`Scan(*time.Time)` 每秒失败 | 被第 1 层完全掩盖，只有强行打开 Start 后才暴露 |
| 3 | poller 从未消费，4650 行滞留、`dedup_key` 永不释放，`ON CONFLICT DO NOTHING` 把每次开关事件**在入队处吞掉** | 审计日志有 4 次开关操作，outbox 表里零条事件——两边对不上才发现 |
| 4 | 开机水位跳过历史行，这些毒行永远不会被清理 | 重启只是让桶重建一次，毒池仍在，所以「重启能好一阵」 |
| 5 | `SetSchedulable` 只在**关闭**时直写账号快照，开启靠（已被吞掉的）outbox | 关闭立刻生效、开启不生效，现象极不对称 |

关键教训：**1 掩盖 2，2 制造 3，3 制造 4**。只修任何一层都不够，而且修了第 1 层才能看见第 2 层。查这类问题不要满足于「找到一个能解释现象的原因」。

### 排查手法（下次直接照做）

线上是单机 SQLite，可以把**真实数据搬到本地**复现，比在生产加日志安全得多：

```bash
# 1. 远端做一致性快照（不要直接拷 .db，WAL 会撕裂）
ssh <vps> 'python3 -c "
import sqlite3
src = sqlite3.connect(\"file:/path/data/sub2api.db?mode=ro\", uri=True)
dst = sqlite3.connect(\"/tmp/repro.db\"); src.backup(dst); dst.close()"'
scp <vps>:/tmp/repro.db /tmp/lab/data/sub2api.db && ssh <vps> 'rm -f /tmp/repro.db'

# 2. 本地起同一份代码，指向副本，log.level: debug、端口改掉、redis.enabled: false
cd backend && go build -o /tmp/lab/server ./cmd/server
DATA_DIR=/tmp/lab/data /tmp/lab/server

# 3. 改本地库的 users.password_hash 换个已知密码 → 正常登录拿 admin JWT
#    （不要手工铸 token，会被 session 绑定校验拦下）
# 4. 用 admin API 按审计日志的顺序重放操作，再打网关请求
```

配套技巧：

- **`audit_logs` 表能还原精确操作序列**（谁、何时、`request_body` 里的原始参数）。`accounts.updated_at` 只告诉你「变过」，不告诉你「变成什么」，别拿它推断。
- **`api_keys.key` 是明文存的**，可以直接取来在本地打真实网关请求。
- 判定资格的关卡散在多处，与其读代码猜，不如**临时在候选循环里逐门打印拒绝原因**（本次就是这么定位的，验证完删掉，别提交）。
- 注意 `scheduler_outbox.created_at` 是 UTC 且无时区后缀，而 `accounts.updated_at` 带 `+08:00`——**比时间线前先统一时区**，否则会得出完全相反的结论。
- `pkill -f <路径片段>` 会连自己的 shell 一起杀掉，用 `for p in $(pgrep -x server); do kill $p; done`。

### 回归测试落点

`internal/repository/scheduler_outbox_enqueue_replace_test.go`、`internal/service/scheduler_snapshot_initial_purge_test.go`。动 outbox / 快照传播链路时先跑这两个。
